insert into my_app_department(name,address)
values
    ('sales_department', 'Osh'),
    ('IT_department', 'Bishkek'),
    ('accounting_department', 'Naryn'),
    ('customer_service_department', 'Talas');

select * from my_app_department;

insert into my_app_position(name)
values
    ('Active Sales Manager'),
    ('Direct Sales Manager'),
    ('Web Designer'),
    ('IT recruiter'),
    ('Accountant'),
    ('Chief Accountant'),
    ('Account Manager'),
    ('Head of Sales Department');
  
 
select * from my_app_position;

insert into my_app_employee (fullname, birth_date, salary, receipt_date, department_id, position_id)
values
    ('Иванов Иван Иванович', '1985-10-05', 60000, '2016-01-15', 1, 2),
    ('Асанов Асан Асанович', '1982-10-10', 70000, '2014-02-20', 1, 5),
    ('Эргешов Али Айбекович', '1979-02-11', 55000, '2008-03-10', 1, 7),
    ('Асанова Наргиза Эсенгуловна', '1984-03-02', 48000, '2010-04-05', 1, 4),
    
    ('Батов Иван Иванович', '1989-01-01', 35000, '2011-01-01', 2, 3),
    ('Аскарова Жамиля Асановна', '1985-03-15', 60000, '2012-02-20', 2, 5),
    ('Сабитов Фарид Мухаммадович', '1982-10-10', 45000, '2010-01-01', 2, 6),
    ('Бакытова Алина Султановна', '1991-07-20', 40000, '2008-01-01', 2, 1),
   
   
    ('Омурбеков Сыймык ', '1975-01-01', 80000, '2015-01-11', 3, 4),
    ('Аматов Санжар Урматович', '1987-03-03', 60000, '2010-02-02', 3, 1),
    ('Федина Галина Викторовна', '1990-05-10', 35000, '2017-03-03', 3, 8),
    ('Ашимов Мирлан Айбекович', '1980-07-05', 50000, '2015-04-01', 3, 2),
   
   
  	('Жапаров Дастан Нурланович', '1985-05-01', 40000, '2023-05-12', 4, 5),
    ('Данин Артем Александрович', '1990-08-11', 35000, '2023-06-05', 4, 3),
    ('Аданова Алия Омурбековна', '1995-05-09', 25000, '2023-07-02', 4, 4),
    ('Федеев Арсен Денисович', '1992-07-08', 30000, '2023-04-004', 4, 2);
	
	
select * from my_app_employee;


DELETE FROM  my_app_employee WHERE id > 12;

drop table my_app_employee;

create table my_app_employee
(
	 id SERIAL PRIMARY KEY,
	 fullname VARCHAR(50), 
	 birth_date DATE, 
	 salary INTEGER, 
	 receipt_date DATE, 
	 department_id INTEGER REFERENCES my_app_department(id) ON DELETE CASCADE, 
	 position_id INTEGER REFERENCES position (id) ON DELETE CASCADE
);

select * from my_app_employee
ORDER BY salary desc;

select * from my_app_employee
ORDER BY birth_date desc, receipt_date asc;

select * from my_app_employee
where salary >= 20000 and salary <= 50000;

select 
	fullname,
	birth_date,
	salary,
	receipt_date,
	department_id, 
	position_id
from my_app_employee as e
INNER JOIN my_app_department as d on e.department_id = d.id
where d.name = 'IT_department'
ORDER BY e.fullname;

select d.name as department_name,
count(e.id) as employee_count
from my_app_department as d
LEFT JOIN my_app_employee as e on d.id = e.department_id
GROUP BY d.name
ORDER BY employee_count asc;

select d.name as department_name,
avg(e.salary) as average_salary
from my_app_department as d
LEFT JOIN my_app_employee as e on d.id = e.department_id
GROUP BY d.name;

select
    e.fullname,
    e.birth_date,
    e.salary,
    e.receipt_date,
    d.name as department_name,
    p.name as position_name
from my_app_employee as e
INNER JOIN my_app_department as d on e.department_id = d.id
INNER JOIN my_app_position as p on e.position_id = p.id;




