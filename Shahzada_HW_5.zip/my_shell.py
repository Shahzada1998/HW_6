from my_app.models import *

employees = Employee.objects.all()
employees

employees = Employee.objects.all().values_list('fullname', 'salary').order_by('-salary')
employees

new_emp = Employee.objects.create(
    fullname='Навуходоно́сор',
    birth_date='1980-01-01',
    salary=35000,
    receipt_date='2010-01-01',
    department_id=2,
    position_id=4)

new_emp.save()
new_emp.department.name

employees = Employee.objects.all().order_by('-birth_date', 'receipt_date')
employees

from django.db.models import Q

employees = Employee.objects.filter(Q(salary__lt=50000) | Q(salary__gt=20000))
employees

accounting_department = Department.objects.get(name='accounting_department')
accounting_department

accounting_employees = Employee.objects.filter(department=accounting_department).order_by('fullname')
accounting_employees

from django.db.models import Count

departments = Department.objects.annotate(employee_count=Count('employee')).order_by('employee_count')
departments

employees = Employee.objects.values('department_id').annotate(department_count=Count('department'))
employees

from django.db.models import Avg

average_salary = Department.objects.annotate(avg_salary=Avg('employee__salary'))
average_salary

employees_salary = Employee.objects.all().annotate(salary_count=Avg('salary'))
employees_salary

